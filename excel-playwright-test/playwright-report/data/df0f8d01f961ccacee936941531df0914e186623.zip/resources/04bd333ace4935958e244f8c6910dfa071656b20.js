"use strict";(self.odspNextWebpackJsonp=self.odspNextWebpackJsonp||[]).push([["recent.resx","file-browser.resx"],{504:e=>{e.exports=JSON.parse('{"b":"Only available when online","a":"{0}. Disabled while offline"}')}
,496:e=>{e.exports=JSON.parse('{"a":"Your OneDrive account is not provisioned"}')}
,522:e=>{e.exports=JSON.parse('{"a":"Skip to main content"}')}
,1216:e=>{e.exports=JSON.parse('{"a":"Show more"}')}
,1014:e=>{e.exports=JSON.parse('{"b":"Copilot","a":"Copilot is only available when online"}')}
}]),define("recent.resx",[],{});