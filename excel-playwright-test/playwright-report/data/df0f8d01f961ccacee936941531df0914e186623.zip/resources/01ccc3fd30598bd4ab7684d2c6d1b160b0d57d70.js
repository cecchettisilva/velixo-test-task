"use strict";(self.odspNextWebpackJsonp=self.odspNextWebpackJsonp||[]).push([["home.resx"],{8451:e=>{e.exports=JSON.parse('{"a":"Catch up on the latest file activity"}')}
,2122:e=>{e.exports=JSON.parse('{"a":"Show Copilot actions for this item"}')}
,504:e=>{e.exports=JSON.parse('{"b":"Only available when online","a":"{0}. Disabled while offline"}')}
,496:e=>{e.exports=JSON.parse('{"a":"Your OneDrive account is not provisioned"}')}
,1431:e=>{e.exports=JSON.parse('{"a":"{0} {1}","d":"just now","c":"Just now","e":"{0}h ago","f":"{0}m ago","i":"Sunday","g":"Monday","k":"Tuesday","l":"Wednesday","j":"Thursday","b":"Friday","h":"Saturday"}')}
,1421:e=>{e.exports=JSON.parse('{"a":"Clear","b":"Filter by name or person"}')}
,1063:e=>{e.exports=JSON.parse('{"a":"Select all rows"}')}
,1061:e=>{e.exports=JSON.parse('{"a":"Select row"}')}
,1062:e=>{e.exports=JSON.parse('{"a":"{0} selected"}')}
,1422:e=>{e.exports=JSON.parse('{"a":"Filter list"}')}
,996:e=>{e.exports=JSON.parse('{"a":"Add column","b":"Click to see more","c":"Error in calculation","f":"Selection cell. Use space to toggle selection","e":"Row selection","d":"One or more fields have an error. Click to navigate to error field."}')}
,1423:e=>{e.exports=JSON.parse('{"a":"Nature is a source of beauty and tranquility. It provides us with fresh air, scenic landscapes, and a habitat for diverse wildlife. Connecting with nature nourishes our souls and reminds us of the importance of preserving our environment for future generations."}')}
,845:e=>{e.exports=JSON.parse('{"RelativeDateTime_AFewSeconds":"A few seconds ago","RelativeDateTime_AFewSeconds_StartWithLowerCase":"a few seconds ago","RelativeDateTime_AFewSecondsFuture":"In a few seconds","RelativeDateTime_AFewSecondsFuture_StartWithLowerCase":"in a few seconds","RelativeDateTime_AboutAMinuteFuture":"In about a minute","RelativeDateTime_AboutAMinuteFuture_StartWithLowerCase":"in about a minute","RelativeDateTime_LessThanAMinute":"Less than a minute ago","RelativeDateTime_LessThanAMinute_StartWithLowerCase":"less than a minute ago","RelativeDateTime_AboutAMinute":"About a minute ago","RelativeDateTime_AboutAMinute_StartWithLowerCase":"about a minute ago","RelativeDateTime_XMinutesFuture":"In {0} minute||In {0} minutes","RelativeDateTime_XMinutesFuture_StartWithLowerCase":"in {0} minute||in {0} minutes","RelativeDateTime_XMinutesFutureIntervals":"1||2-","RelativeDateTime_XMinutesIntervals":"1||2-","RelativeDateTime_AboutAnHourFuture":"In about an hour","RelativeDateTime_AboutAnHourFuture_StartWithLowerCase":"in about an hour","RelativeDateTime_AboutAnHour":"About an hour ago","RelativeDateTime_AboutAnHour_StartWithLowerCase":"about an hour ago","RelativeDateTime_Tomorrow":"Tomorrow","RelativeDateTime_Tomorrow_StartWithLowerCase":"tomorrow","RelativeDateTime_Yesterday":"Yesterday","RelativeDateTime_Yesterday_StartWithLowerCase":"yesterday","RelativeDateTime_YesterdayAndTime":"Yesterday at {0}","RelativeDateTime_YesterdayAndTime_StartWithLowerCase":"yesterday at {0}","DateTime_DateAndTime":"{0} at {1}","RelativeDateTime_TomorrowAndTime":"Tomorrow at {0}","RelativeDateTime_TomorrowAndTime_StartWithLowerCase":"tomorrow at {0}","RelativeDateTime_XHoursFuture":"In {0} hour||In {0} hours","RelativeDateTime_XHoursFuture_StartWithLowerCase":"in {0} hour||in {0} hours","RelativeDateTime_XHours":"{0} hour ago||{0} hours ago","RelativeDateTime_XHoursFutureIntervals":"1||2-","RelativeDateTime_XHoursIntervals":"1||2-","RelativeDateTime_DayAndTime":"{0} at {1}","RelativeDateTime_DayAndTime_CommaSeparator":"{0}, {1}","RelativeDateTime_XDaysFuture":"{0} day from now||{0} days from now","RelativeDateTime_XDays":"{0} day ago||{0} days ago","RelativeDateTime_XDaysFutureIntervals":"1||2-","RelativeDateTime_XDaysIntervals":"1||2-","RelativeDateTime_Today":"Today","RelativeDateTime_Today_StartWithLowerCase":"today","RelativeDateTime_XMinutes":"{0} minute ago||{0} minutes ago","MonthAndYear":"{0} {1}","today":"Today","yesterday":"Yesterday","FriendlyDateTime_JustNow_withinSentence":"just now","FriendlyDateTime_JustNow_asSentence":"Just now","FriendlyDateTime_hoursShort":"{0}h ago","FriendlyDateTime_minutesShort":"{0}m ago"}')}
,8448:e=>{e.exports=JSON.parse('{"a":"SharePoint App"}')}
,2129:e=>{e.exports=JSON.parse('{"a":"Share this item with other people","b":"Show more actions for this item"}')}
,1203:e=>{e.exports=JSON.parse('{"b":"All","e":"Filter by {0} files","f":"Filter files by {0}","g":"Filter by Folders","h":"Filter by Microsoft Lists","c":"Archived","k":"More","d":"Available offline","n":"Videos","l":"Photos","a":"Agent","m":"Research","j":"Hidden","i":"Folder"}')}
,2125:e=>{e.exports=JSON.parse('{"f":"My Files","h":"My Whiteboards","g":"My Lists","i":"{0}\\u0027s Files","j":"{0}\\u0027s Lists","k":"{0}\\u0027s Whiteboards","c":"External App","b":"Location: {0}","a":"{0} by {1}","l":"Shared by {0}","e":"Modified by {0}","d":"Favorited {0}"}')}
,2128:e=>{e.exports=JSON.parse('{"a":"Activity","b":"This item is favorited","c":"Available offline"}')}
,2124:e=>{e.exports=JSON.parse('{"a":"Opens profile card for {0}"}')}
,1424:e=>{e.exports=JSON.parse('{"b":"No results found","a":"A magnifying glass"}')}
,1425:e=>{e.exports=JSON.parse('{"a":"File list updated; {0} items"}')}
,8441:e=>{e.exports=JSON.parse('{"b":"Activity","a":"Activity"}')}
,2123:e=>{e.exports=JSON.parse('{"b":"Name","a":"Name"}')}
,2127:e=>{e.exports=JSON.parse('{"b":"Opened","a":"Opened date"}')}
,2126:e=>{e.exports=JSON.parse('{"b":"Owner","a":"Owner"}')}
,1395:e=>{e.exports=JSON.parse('{"a":"Exclamation mark","i":"Network offline","f":"Sorry, something went wrong","e":"We can\\u0027t connect to OneDrive","h":"Connect to the internet to open this page","b":"Unknown render failure.","c":"Check your internet connection and try again.","d":"Reconnect to the internet to open this page.","g":"Can\\u0027t open this page offline right now. Please try again later."}')}
,1429:e=>{e.exports=JSON.parse('{"b":"Your recent files will show up here","c":"You haven\\u0027t viewed any documents recently","a":"Keep your documents in OneDrive to get to them from any device."}')}
,1432:e=>{e.exports=JSON.parse('{"a":"Recent"}')}
,1430:e=>{e.exports=JSON.parse('{"a":"List of recently accessed files","c":"Try again with different words, phrases, or filters.","d":"Selection cell. Use space to toggle selection for {0}.","b":"Opened {0}"}')}
,8447:e=>{e.exports=JSON.parse('{"b":"Catch me up on important files","a":"Ask a question about these files"}')}
,8449:e=>{e.exports=JSON.parse('{"c":"Summarize \\u0022{0}\\u0022","b":"Give a recap of this meeting in three sentences using a bulleted list","a":"Give a recap of this meeting in three key topics"}')}
,8452:e=>{e.exports=JSON.parse('{"a":"Get a summary of new mentions, comments, and files shared with you.","b":"Catch me up"}')}
,8450:e=>{e.exports=JSON.parse('{"a":"For you"}')}
,8444:e=>{e.exports=JSON.parse('{"c":"Open","a":"Go to comment","b":"Go to task","f":"Watch recording","e":"Summarize","d":"Recap this meeting"}')}
,8453:e=>{e.exports=JSON.parse('{"a":"Favorite","c":"Unfavorite","b":"Add this item to Favorites","d":"Remove this item from Favorites"}')}
,8442:e=>{e.exports=JSON.parse('{"a":"Shared from outside your organization","b":"Opens profile card for {0}"}')}
,1443:e=>{e.exports=JSON.parse('{"a":"Home"}')}
}]);