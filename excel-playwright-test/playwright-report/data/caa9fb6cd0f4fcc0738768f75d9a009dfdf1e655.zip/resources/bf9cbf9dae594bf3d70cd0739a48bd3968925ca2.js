"use strict";
var TellmeStringsArray = ["Recently Used", "Suggested", "People", "Documents", "Actions", "Find in Document", "See more results for", "Quick Answer", "Entity", "Definition", "Get Help on"];
var TellmeStringsManager = {
    TellmeStringsArray,
    get(x) {
        return this.TellmeStringsArray[x];
    }
};
