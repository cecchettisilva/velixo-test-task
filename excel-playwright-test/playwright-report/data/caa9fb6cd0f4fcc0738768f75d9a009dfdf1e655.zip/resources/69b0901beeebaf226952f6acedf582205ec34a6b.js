"use strict";(self.webpackChunk_1js_office_start_office_home=self.webpackChunk_1js_office_start_office_home||[]).push([[51091],{466251:(e,t,n)=>{n.d(t,{Q:()=>i});var a=n(427667),o=n(957259),r=n(955434);async function i(){return new Promise(((e,t)=>{const n=(0,a.HI)();if(void 0!==n)n.then((()=>e(window.O365Shell))).catch((e=>{t(e)}));else{const e="ShellRendered promise does not exist, unable to get shell status";(0,o.a)({eventName:"Shell_Shim_Load",owningTeam:r.O.Unknown,errorType:"Shell_Bootstrap_Error",debugInfo:e}),t(new Error(e))}}))}},993885:(e,t,n)=>{n.d(t,{L:()=>r});var a=n(427972),o=n(313340);async function r(){const e=await(0,o.x)(),{correlationId:t,defaultLinkTarget:n,getAccessToken:r,inMockMode:i,jwtAuthEnabled:s,officeHomeApiRoot:p,router:l,preferredCulture:c,sessionId:u,workload:d}=e,m=await(0,a.B)();if(!m)throw new Error("Capabilities not available");return{capabilities:m,context:e,correlationId:t,defaultLinkTarget:n,getAccessToken:r,inMockMode:i,jwtAuthEnabled:s,officeHomeApiRoot:p,preferredCulture:c,router:l,sessionId:u,workload:d}}},731225:(e,t,n)=>{n.d(t,{R:()=>s});var a=n(313340),o=n(289314),r=n(44912);let i;async function s(){if(!i){const e=await(0,a.x)(),t=e.workload===r.w.Hwa||(0,o.o)();i=t?await n.e(30926).then(n.bind(n,239752)).then((t=>({launchFile:t.getLaunchFileFunc(e),launchInDesktopApps:t.launchInDesktopApps,launchTemplate:t.launchTemplate,openFileInExplorer:t.openFileInExplorer}))):{launchFile:()=>Promise.reject(),launchInDesktopApps:()=>Promise.reject(),launchTemplate:()=>Promise.reject(),openFileInExplorer:()=>Promise.reject()}}return i}},7032:(e,t,n)=>{n.d(t,{x:()=>h});var a=n(313340),o=n(44912),r=n(267791),i=n(54032),s=n(625017),p=n(955434),l=n(910748),c=n(858965),u=n(737801),d=n(545121);const m=async(e,t,n)=>{if(t.disableDefaultLinkBehavior||!event||event.defaultPrevented)try{const a=t.action;return await(0,d.H)(e,{action:a},n)}catch{return{success:!1,message:"launchWebApp:launchUrlException"}}return{success:!1,message:"launchWebApp:fallThrough"}};var f=n(696235),y=n(75412);const h=async(e,t)=>{let n={success:!1};const h="launchApp";try{const i=await(0,a.x)(),{appName:s,filePath:p,webUrl:l,fileType:c,url:h,templateBinaryUrl:A}=e,g=i.workload==o.w.Hwa&&s&&await(0,y.w)(s);if((0,r.u)({eventName:"LaunchApp_Debug",params:{appName:s??"",fileType:c??"",shouldOpenHwaInNativeFile:g}}),g){const{disableDefaultLinkBehavior:a,event:o}=e,i=!o||o.defaultPrevented||a?void 0:()=>o?.preventDefault();let d;try{d=await(0,u.b)({appName:s,fileType:c,filePath:p??(e.useUrl?h:""),webUrl:l,prelaunchCallback:i,templateBinaryUrl:A}),(0,r.u)({eventName:"LaunchApp_Debug_LaunchNativeFileCompleted",params:{success:d.success}}),(0,f.R)({launchInstrumentationParams:t,success:d.success}),d.success&&(n={...d,result:"Native"})}catch{}d?.success||(n=await m(h,e,t))}else if(h){const a="OpenInApp",{targetTab:o}=e;n=await(0,d.H)(h,{action:a,targetTab:o},t),(0,r.u)({eventName:"LaunchApp_Debug_LaunchUrlCompleted",params:{success:n.success}})}}catch(e){let t,n;e instanceof Error?t=e.message:"string"==typeof e?t=e:"object"==typeof e&&(t=e?.toString()),(0,i.l)({debugInfo:t,errorType:"LaunchApp_Error",eventName:h,errorClassification:s.J.FeatureUnusable,isCustomerImpacting:!0,owningTeam:p.O.Unknown,error:e}),t&&(0,r.u)({eventName:h,params:{DebugInfo:t,Message:n??""}})}finally{(0,l.t8)({eventName:h,featureName:c.Mc.LauncherService,params:{Success:n.success,Message:n.message??"",AppLaunchResult:n.result??""}})}return n}},737801:(e,t,n)=>{n.d(t,{b:()=>s});var a=n(910748),o=n(858965),r=n(993885),i=n(731225);const s=async e=>{const{launchFile:t,launchInDesktopApps:n}=await(0,i.R)(),{capabilities:s}=await(0,r.L)();let p={success:!1};return e.webUrl&&s.lorByDefaultEnabled&&(p=await n(e)),(0,a.t8)({featureName:o.Mc.LinksOpenRight,eventName:"LinksOpenRightLaunchNativeFile"}),p.success?{success:p.success}:t(e)}},75412:(e,t,n)=>{async function a(e){return(await Promise.all([n.e(17996),n.e(49786),n.e(54175),n.e(42516)]).then(n.bind(n,254175))).getInstalledApp(e).then((e=>null!==e)).catch((()=>!1))}n.d(t,{w:()=>a})},135183:(e,t,n)=>{n.d(t,{i:()=>r});var a=n(324261);const o=[a.QF,a.bl,a.xp,a.Ol];function r(e,t){return t&&o.includes(t)?t:e}},868455:(e,t,n)=>{n.d(t,{q:()=>r});var a=n(466251),o=n(280686);function r(){let e,t;return new Promise((async n=>{e=await(0,a.Q)(),t=e?.Apps.OnAppsUpdated((e=>{const t=[];if(e.Apps)for(const n of e.Apps)"FirstParty"!==n.CollectorId&&t.push((0,o.j)(n));n(t)}))})).finally((()=>{t&&e?.Apps.RemoveOnAppsUpdated(t)}))}},649742:(e,t,n)=>{n.d(t,{T:()=>r});var a=n(225268),o=n(833770);async function r(){return(0,a.D)(o.D)}},280686:(e,t,n)=>{function a(e){return{ChangeColorInDarkMode:"Dynamics"===e.CollectorId,Color:e.BackgroundColor,Id:e.Id,AppId:e.Id,CollectorId:e.CollectorId,Title:e.AriaLabel?e.AriaLabel:"",SubText:e.Subtitle,Text:e.Title,IsNativeClientOnlyApp:e.isNativeClientOnlyApp,Url:e.LaunchFullUrl?e.LaunchFullUrl.trim():"",IconUnicodeCodepointCssClass:"ms-fcl-tp ms-Icon ms-Icon--OfficeAddinsLogo",ThirdPartyIcon:e.IconAnonymousUrl?e.IconAnonymousUrl:null,Referral:e.Id,IsThirdParty:!0}}n.d(t,{j:()=>a})},385733:(e,t,n)=>{n.d(t,{Oe:()=>u,e_:()=>r,fp:()=>o,q0:()=>l,wj:()=>c,yT:()=>p});var a=n(996304),o=function(e){return e.SEARCH="SEARCH",e.APPGALLERY="APPGALLERY",e.APPBAR="APPBAR",e}({});const r=new Set([a.o.Word,a.o.Excel,a.o.PowerPoint]),i={[a.o.Word]:"https://word.cloud.microsoft",[a.o.Excel]:"https://excel.cloud.microsoft",[a.o.PowerPoint]:"https://powerpoint.cloud.microsoft"},s={[a.o.Word]:"word.cloud.microsoft",[a.o.Excel]:"excel.cloud.microsoft",[a.o.PowerPoint]:"powerpoint.cloud.microsoft"};function p(e,t){const n=i[e];return n?`${n}?WdOrigin=OFFICECOM-WEB.${t}`:""}function l(e){try{const t=new URL(e).host;return Object.values(s).some((e=>e===t))}catch{return!1}}function c(e,t,n,a){return r.has(e.Id)&&(n||l(e.Url))?u(e,t,a):e}function u(e,t,n){if(!i[e.Id])return e;let a=p(e.Id,t);if(n){const t=function(e){try{return new URL(e).searchParams.get("login_hint")||""}catch{return""}}(e.Url);t&&(a=function(e,t){try{const n=new URL(e);return n.searchParams.set("login_hint",t),n.toString()}catch{return e}}(a,t))}return{...e,Url:a,InAppNav:!1}}},676383:(e,t,n)=>{n.d(t,{D8:()=>i,KG:()=>o,T$:()=>a,mw:()=>p,w7:()=>s});const a="AppBar",o="LaunchTile",r="SuggestedTile",i="AppAquisitionLink",s={launch:"launch",moreInfo:"moreInfo",privacy:"privacy",termsOfUse:"termsOfUse",permissions:"permissions",description:"description",install:"install",uninstall:"uninstall",appAcquisitionLinkClick:"appAcquisitionLinkClick",flyoutButtonHover:"flyoutButtonHover",flyoutOpened:"flyoutOpened",flyoutRendered:"flyoutRendered",userSearch:"userSearch",appTileHover:"appTileHover",renderError:"renderError",appBarImpression:"appBarImpression",suggestedLinkClick:"suggestedLinkClick",seeAllButtonClick:"seeAllButtonClick",pin:"pin",unpin:"unpin",reorder:"reorder",appIconError:"appIconError",contentDropped:"contentDropped"},p={launch:e=>({originator:o,type:s.launch,data:e}),moreInfo:e=>({originator:o,type:s.moreInfo,data:e}),privacy:e=>({originator:r,type:s.privacy,data:e}),termsOfUse:e=>({originator:r,type:s.termsOfUse,data:e}),permissions:e=>({originator:r,type:s.permissions,data:e}),description:e=>({originator:r,type:s.description,data:e}),install:e=>({originator:r,type:s.install,data:e}),uninstall:e=>({originator:o,type:s.uninstall,data:e}),appAcquisitionLinkClick:e=>({originator:i,type:s.appAcquisitionLinkClick,data:e}),flyoutButtonHover:e=>({originator:a,type:s.flyoutButtonHover,data:e}),flyoutOpened:e=>({originator:a,type:s.flyoutOpened,data:e}),flyoutRendered:e=>({originator:a,type:s.flyoutRendered,data:e}),userSearch:e=>({originator:"Flyout",type:s.userSearch,data:e}),pin:e=>({originator:o,type:s.pin,data:e}),unpin:e=>({originator:o,type:s.unpin,data:e}),reorder:e=>({originator:o,type:s.reorder,data:e}),appTileHover:e=>({originator:o,type:s.appTileHover,data:e}),appIconError:e=>({originator:o,type:s.appIconError,data:e}),renderError:e=>({originator:a,type:s.renderError,data:e}),appBarImpression:e=>({originator:a,type:s.appBarImpression,data:e}),suggestedLinkClick:e=>({originator:"SuggestedLinkTile",type:s.suggestedLinkClick,data:e}),seeAllButtonClick:()=>({originator:"SeeAllButton",type:s.seeAllButtonClick}),contentDropped:e=>({originator:o,type:s.contentDropped,data:e})}},23040:(e,t,n)=>{n.d(t,{b:()=>s});var a=n(571124),o=n(338316);const r=e=>e.updateTuiTargetElementData,i=e=>e instanceof HTMLElement?{element:e}:e;function s(e){const t=(0,o.W)(r),n=(0,a.useCallback)(((e,n)=>a=>{const o=i(a);t(e,o),n?.(o?.element??null)}),[t]);return(0,a.useMemo)((()=>e?n(e):n),[n,e])}},338316:(e,t,n)=>{n.d(t,{W:()=>a});const a=(0,n(465638).create)(((e,t)=>({elementMap:new Map,activeSequence:void 0,disabled:!1,updateTuiTargetElementData:(n,a)=>{t().disabled||e((e=>({elementMap:new Map(e.elementMap).set(n,a)})))},setActiveTeachingSequence:function(t,n){let a=arguments.length>2&&void 0!==arguments[2]?arguments[2]:0,o=arguments.length>3&&void 0!==arguments[3]&&arguments[3];e((()=>({activeSequence:{callouts:t,markSequenceAsSeenFn:n,startingIndex:a,shouldUpdateNewUserState:o}})))},clearActiveTeachingSequence:()=>e({activeSequence:void 0}),setDisabled:()=>e({disabled:!0,activeSequence:void 0,elementMap:new Map})})))},591646:(e,t,n)=>{n.d(t,{Z:()=>M});var a=n(676383),o=n(925254),r=n(526456),i=n(135183),s=n(439491),p=n(108592),l=n(435493),c=n(448485),u=n(918613),d=n(166649),m=n(124493),f=n(663215),y=n(430054),h=n(571124),A=n(652410),g=n(803012),b=n(910748),w=n(858965),I=n(186385),v=n(219650),B=n(993071),k=n(21808),S=n(855894),T=n(949251),C=n(372921),E=n(44912);const L=e=>{let{children:t,appbarConnectorService:L,renderEventInterceptor:M=!1}=e;const{tileData:P}=h.useContext(p.K),D=(0,r.i)((e=>e.userData)),x=(0,r.i)((e=>e.setUserData)),{data:U}=(0,l.T)(),N=(()=>(0,A.P)()?"AppBarIA":"AppBar")(),_=(0,o.e)(),R=e=>{const t=P?.m365Apps;for(const n of t.edges)if(n.node.id===e){const t=n.node.platformType;return{sanitizedAppId:(0,i.i)(e,t),platformType:t}}return{}},O=function(e){return{async bubble(t){if(t.event.originator===a.KG||t.event.originator===a.D8||t.event.originator===a.T$)return await async function(e,t){const r=e.event;switch(r.type){case a.w7.launch:!async function(e,t){const n=e.data&&e.data(),a=(0,o.e)();if(n){let o=!!n.launchOut;o||await(0,I.q)(n.tileID,n.platformType)&&(o=!0);const r={};null!=n.tilePosition&&(r[g.g.TilePosition]=n.tilePosition.toString()),null!=n.tileHostContext&&(r[g.g.TileHostContext]=n.tileHostContext),n.tileID===a&&(0,b.t8)({featureName:w.Mc.CopilotFunnel,eventName:"OnCopilotAppbarTileClick"}),await(0,I.k)(n.tileID,n.platformType,e.type,o,r,t)}}(r,t);break;case a.w7.moreInfo:(await n.e(43287).then(n.bind(n,943287))).moreInfoEventHandler(r);break;case a.w7.appAcquisitionLinkClick:(await n.e(88805).then(n.bind(n,488805))).appAcquisitionLinkClickEventHandler(r,t);break;case a.w7.uninstall:(await n.e(22798).then(n.bind(n,622798))).uninstallEventHandler(r);break;case a.w7.flyoutOpened:(await n.e(52116).then(n.bind(n,52116))).flyoutOpenedEventHandler(r,t);break;case a.w7.renderError:(await n.e(80774).then(n.bind(n,780774))).renderErrorEventHandler(r,t);break;case a.w7.appBarImpression:(await n.e(74195).then(n.bind(n,474195))).appBarImpressionEventHandler(r,t)}}(t,e),Promise.resolve()}}}(N),F=async e=>{e.event.type===a.w7.launch&&e.event.data&&(e=>{const t=Date.now(),n=P?.m365Apps;if(n?.edges)for(const a of n.edges)if(a.node.id){const n=null!=e&&e===a.node.id;if(n){const e=!!a.node.isInUse&&n;L?.onAppButtonClick(t,e),e||a.node.id!==_||(0,u.zX)(U?.result?.pauseSchedulerTimeout?.valueInMs)}}})(e.event.data().tileID),await O.bubble(e),L?.updateCurrentAppVerticalPosition()},H={async bubble(e){await F(e)}},G=(e=>{const{data:t}=(0,C.w)(),{data:n}=(0,B.E)(),{data:a}=(0,k.S)(),o=(0,v.YU)(),r=(0,S.Yj)(),i=(0,T.w)()?.data,p=(!o&&!r)??!1,l=i?.result?.copilotGates?.copilotCoreAppsUsageEnabled??!1,u=e,m=t?.appBarResources;return o&&(u.m365Apps.edges=e.m365Apps.edges.filter((e=>{const{isPinnable:t}=e.node;return!1===t}))),{useLazyLoadQuery:(e,t,r)=>{let i={data:void 0};return"Document"===e.kind&&e.definitions.forEach((e=>{if("OperationDefinition"===e.kind&&e.name)switch(e.name.value){case"AppBarQuery":i={data:u};break;case"AppBarControlQuery":i={data:{views:{appBarControl:{id:"AppBarControl",rootNavigationAriaLabel:"",animateSelection:!0,flyoutIcon:{__typename:"InternalIcon",name:n?.appBarOverflowOnlyEnabled?"MoreIcon":"AppsIcon"},flyoutIconSelected:{__typename:"InternalIcon",name:n?.appBarOverflowOnlyEnabled?"MoreIconSelected":"AppsIconSelected"},enableAIHub:o,enableBrandLogo:!p,enableVisualRefreshStyles:!0,enableRockSteadyForM365:p,enableMicaV2WebStyles:!1,tileBehavior:{transparent:!0,shouldRemoveLockedAppsFromPinnedApps:l,shouldShowLabel:!0,useOutlineIcon:!0,pinningEnabled:!!n?.appBarPinningEnabled,dragDropEnabled:!!n?.appBarDragDropEnabled,tileContextMenu:{openInNewTabItemLabel:a?.workload===E.w.Hwa?m?.openInBrowser:m?.openInNewTab,aboutAppItemLabel:m?.aboutApp,unpinAppItemLabel:m?.unpinApp,pinAppItemLabel:m?.pinApp,uninstallAppItemLabel:m?.uninstallApp,moveAppUpItemLabel:m?.moveAppUp,moveAppDownItemLabel:m?.moveAppDown,pinAriaAnnouncement:m?.pinAriaAnnouncement,unpinAriaAnnouncement:m?.unpinAriaAnnouncement},platformAppCommands:{aboutCommandEnabled:!!n?.m365AppsAboutEnabled,uninstallCommandEnabled:!!n?.sharedServicesEnabled}},appAcquisitionLinkBehavior:{linkFormat:"IconText"},localizedStrings:{flyoutButtonText:n?.appBarOverflowOnlyEnabled?void 0:m?.flyoutButtonText,flyoutButtonTitle:m?.viewMoreApps,flyoutEmptyStateMessage:m?.noAppsYet}}}}};break;case"EnableAIHub":i={data:o}}})),i},useMutation:e=>[t=>{const n={data:void 0};return"Document"===e.kind&&e.definitions.forEach((e=>{if("OperationDefinition"===e.kind&&e.name)switch(e.name.value){case"AppBarPinAppMutation":n.data=(e=>{if(!D||!x)return;const{sanitizedAppId:t,platformType:n}=R(e);t&&(0,d.Km)({eventName:c.H.AppBarPinApp,type:"Click",id:t,area:N,result:"Pin",target:"AppBar"});const a=(0,s.cq)(D,e,n,"UserPinned");x(a)})(t.variables.applicationID);break;case"AppBarUnpinAppMutation":n.data=(e=>{if(!D||!x)return;const{sanitizedAppId:t}=R(e);t&&(0,d.Km)({eventName:c.H.AppBarUnpinApp,type:"Click",id:t,area:N,result:"Unpin",target:"AppBar"});const n=(0,s.Ud)(D,e);x(n)})(t.variables.applicationID);break;case"AppBarMovePinnedAppMutation":n.data=((e,t)=>{if(!D||!x)return;const{sanitizedAppId:n,platformType:a}=R(e);n&&(0,d.Km)({eventName:c.H.AppBarMovePinnedApp,type:"Click",id:n,area:N,result:"Move",target:"AppBar"});const o=(0,s.S1)(D,e)?(0,s.L4)(D,e,t):(0,s.L4)((0,s.cq)(D,e,a,"UserPinned"),e,t);x(o)})(t.variables.applicationID,t.variables.newPinnedIndex)}})),new Promise((()=>n))},!1]}})(P),q=h.createElement(m.X,{graphql:G},t);return M?h.createElement(f.kY,{interceptor:async e=>(await F(e),Promise.resolve(e))},q):h.createElement(f.sU,{eventing:H,reactEventMapper:y.u},q)},M=e=>h.createElement(L,e);M.displayName="NovaContextProvider"},186385:(e,t,n)=>{n.d(t,{k:()=>L,q:()=>E});var a=n(733213),o=n(746405),r=n(45949),i=n(427972),s=n(313340),p=n(324261),l=n(109872),c=n(135183),u=n(268030),d=n(451276),m=n(142841),f=n(149663),y=n(854766),h=n(183426),A=n(545121),g=n(7032),b=n(537215),w=n(44912),I=n(649742),v=n(385733),B=n(868455),k=n(996304),S=n(548215);const T=[p.QF],C={};async function E(e,t){const n=await(0,s.x)(),{result:a}=await(0,d.N_)(),o=a?.newWXPHomePagesGates,p=o?.newWXPHomePagesEnabled,c=o?.newWXPHomePagesLoginHintEnabled;if(t&&T.includes(t))return!1;if(e===r.h.pages&&n.workload==w.w.Hwa&&(!n.isBootstrappedFromReactHarmony||a?.launchPagesModuleInWebGates?.launchPagesModuleInWebEnabled))return!0;if(e===r.h.onedrive)return(await(0,y.dw)()).isMsa?!a?.oneDriveConsumerMosAppGates?.oneDriveConsumerMosAppEnabled:a?.oneDriveMosAppGates?.oneDriveMosAppEnabled;if(C[e]){const t=C[e];if("Start"!==t.route)return!1;const n=await(0,i.B)(),a=(0,f.S)(t.app);if(!a||!n?.startPageApps?.has(a))return!0;const o=(await M(p,c)).find((t=>(0,l.J)(t.AppId)===e));return!o?.InAppNav}return!0}async function L(e,t,n,i,l){let u=arguments.length>5&&void 0!==arguments[5]?arguments[5]:"AppBar";const{result:y}=await(0,d.N_)(),{result:w}=await(0,m.qL)(),I=y?.newWXPHomePagesGates,v=I?.newWXPHomePagesEnabled,T=I?.newWXPHomePagesLoginHintEnabled,L=function(e,t,n,o){return e===r.h.copilotMos&&"ModeB"===o?.copilot?.mode?{route:"Chat",type:b.h.Base}:t===p.QF?{route:"M365Apps",type:b.h.Mos,appId:e}:e===r.h.onedrive&&n?.oneDriveMosAppGates?.oneDriveMosAppEnabled?{route:"M365Apps",type:b.h.Mos,appId:a.D.OnedriveMOS}:e===r.h.onedriveMsa&&n?.oneDriveConsumerMosAppGates?.oneDriveConsumerMosAppEnabled?{route:"M365Apps",type:b.h.Mos,appId:a.D.OnedriveMsaMOS}:C[e]??{route:"OfficeHome",type:b.h.Base}}(e,t,y,w),D=(0,h.G)(u,n,(0,c.i)(e,t),i);if(l)for(const e in l)D.clickParams[e]=l[e];if(i){const n=await(0,s.x)(),a="OpenInBrowser";if(await E(e,t)){const t=await async function(e,t,n){const a=await M(t,n);switch(e){case r.h.outlook:return{url:P(k.o.Outlook,a),appName:"outlook"};case r.h.onedrive:return{url:P(k.o.OneDrive,a),appName:""};case r.h.teams:return{url:a.find((e=>e.Id===k.o.Teams||e.Id===k.o.TeamsForLife))?.Url||"",appName:""};case r.h.onenote:return{url:P(k.o.OneNote,a),appName:"onenote"};case r.h.sway:return{url:P(k.o.Sway,a),appName:""};case r.h.todo:return{url:P(k.o.ToDo,a),appName:""};case r.h.familysafety:return{url:P(k.o.FamilySafety,a),appName:""};case r.h.calendar:return{url:P(k.o.Calendar,a),appName:""};case r.h.people:return{url:P(k.o.People,a),appName:""};case r.h.powerautomate:return{url:P(k.o.Flow,a),appName:""};case r.h.clipchamp:return{url:P(k.o.Clipchamp,a),appName:""};case r.h.lists:return{url:P(k.o.Lists,a),appName:""};case r.h.admin:return{url:P(k.o.Admin,a),appName:""};case r.h.copilotExternal:return{url:"https://copilot.microsoft.com/",appName:""};case r.h.pages:return{url:window.location.origin+"/pages/",appName:""};case r.h.search:return{url:window.location.origin+"/searchModule/",appName:""};default:let t=a.find((t=>t.Id==="Shell"+e))?.Url;if(!t){const n=await(0,B.q)();t=n.find((t=>t.Id===e))?.Url}if(!t){const n=await(0,S.b)(),a=n?.result?.workspaces?.find((e=>e.id===o.M6.allApps));t=a?.apps.find((t=>t.servicePrincipalId===e))?.redirectUrl}return{url:t||"",appName:""}}}(e,v,T);if(t){const e=(0,f.S)(t.appName);await(0,g.x)({action:a,appName:t.appName,url:t.url,fileType:e,disableDefaultLinkBehavior:!0},D)}}else{const e=n?.router.getUrlForRoute?.(L);e&&await(0,A.H)(e,{action:a},D)}}else await(0,A.H)(L,{action:"OpenInBrowser"},D,void 0,!1,void 0,{launchSource:u})}async function M(e,t){const n=await(0,I.T)();return n?[...n.coreAndSegmentApps?.map((n=>(0,v.wj)(n,v.fp.APPBAR,e,t)))||[],...n.nonCoreAndSegmentApps||[]]:[]}function P(e,t){return t.find((t=>t.Id===e))?.Url||""}C[r.h.home]={route:"OfficeHome",type:b.h.Base},C[r.h.create]={route:"Create",type:b.h.Base},C[r.h.chat]={route:"Chat",type:b.h.Base},C[r.h.browse]={route:"Browse",type:b.h.Base},C[r.h.pages]={route:"Pages",type:b.h.Base},C[r.h.workplace]={route:"Workplace",type:b.h.Base},C[r.h.assist]={route:"Assist",type:b.h.Base},C[r.h.appgallery]={route:"AppGallery",type:b.h.Base},C[r.h.copilotCmc]={route:"CopilotCmc",type:b.h.Base},C[r.h.word]={route:"Start",type:b.h.Base,app:u.p.Word},C[r.h.excel]={route:"Start",type:b.h.Base,app:u.p.Excel},C[r.h.powerpoint]={route:"Start",type:b.h.Base,app:u.p.PowerPoint},C[r.h.onenote]={route:"Start",type:b.h.Base,app:u.p.OneNote},C[r.h.sway]={route:"Start",type:b.h.Base,app:u.p.Sway},C[r.h.forms]={route:"Start",type:b.h.Base,app:u.p.Forms},C[r.h.visio]={route:"Start",type:b.h.Base,app:u.p.Visio},C[r.h.stream]={route:"Start",type:b.h.Base,app:u.p.Stream},C[r.h.clipchamp]={route:"Start",type:b.h.Base,app:u.p.Clipchamp},C[r.h.aiHubSample]={route:"AiHubSample",type:b.h.Base},C[r.h.search]={route:"SearchModule",type:b.h.Base},C[r.h.aiViewsPlayground]={route:"AIViewsPlayground",type:b.h.Base},C[r.h.experimentModule]={route:"ExperimentModule",type:b.h.Base},C[r.h.clips]={route:"Clips",type:b.h.Base},C[r.h.copilotBoards]={route:"CopilotBoards",type:b.h.Base},C[r.h.library]={route:"Library",type:b.h.Base},C[r.h.teach]={route:"Teach",type:b.h.Base},C[r.h.notebooks]={route:"Notebooks",type:b.h.Base}},108592:(e,t,n)=>{n.d(t,{K:()=>a});const a=n(571124).createContext({tileData:{m365Apps:{edges:[],appAcquisitionLinks:[]}}})},535314:(e,t,n)=>{n.d(t,{m:()=>h});var a=n(588494),o=n(733286),r=n(12801),i=n(292185),s=n(708465),p=n(632791),l=n(54032),c=n(955434),u=n(858965),d=n(625017),m=n(793847);const f="workspaces-api",y=1;async function h(e,t,n,h){const A={correlationId:t.correlationId,getAccessToken:t.getAccessToken,inMockMode:t.inMockMode,jwtAuthEnabled:t.jwtAuthEnabled,officeHomeApiRoot:t.officeHomeApiRoot,myApplicationsUrl:n.myApplicationsUrl,tenantId:e.tenantId,userId:e.objectId,dataBoundary:e.dataBoundary,tenantRegionScope:e.tenantRegionScope||"",acceptLanguage:t.preferredCulture},g=await(0,a.Z)(),b=g?.key?[(0,r.J)(g.key)]:[];return(0,o.Z)((()=>async function(e,t){return new Promise(((n,a)=>{const o=(e.inMockMode?e.officeHomeApiRoot:e.myApplicationsUrl)+"/api/me/getExpandedAssignedWorkspaces",r=function(e){const t={"x-ms-tenant-id":e.tenantId,"x-ms-user-id":e.userId,"x-ms-tenant-region":e.tenantRegionScope,"accept-language":e.acceptLanguage};return e.dataBoundary&&(t["x-ms-tdbr"]=e.dataBoundary),{headers:t}}(e);(0,m.l)(u.Yl.ExpandedWorkspacesRequest,o.toString(),r,e.jwtAuthEnabled,e.getAccessToken,e.officeHomeApiRoot,e.correlationId,"MyApps",{},t).then((e=>{e&&e.data?n({workspaces:e.data,fromCache:t===p.A.CacheOnly}):a()})).catch((e=>{(0,l.l)({eventName:"WorkspaceService_GetWorkspacesError",errorClassification:d.J.PossibleFlawIndicator,isCustomerImpacting:!1,owningTeam:c.O.Infra,error:e}),a(`Failed to get Expanded Workspaces. Status Code: ${e&&e.httpResponse?e.httpResponse.status:""}`)}))}))}(A,p.A.NetworkOnly)),(()=>(0,i.U)({userId:e.puid,collectionName:f,collectionVersion:y,key:f,plugins:b})),(t=>(0,s.c)({userId:e.puid,collectionName:f,collectionVersion:y,key:f,data:t,plugins:b})),h)}},548215:(e,t,n)=>{n.d(t,{b:()=>l});var a=n(698654),o=n(313340),r=n(673217),i=n(451276),s=n(854766),p=n(535314);async function l(){const[e,t,n,l]=await Promise.all([(0,o.x)(),(0,s.dw)(),(0,a.e)(),(0,i.N_)()]);if(t?.isMsa||l?.result?.workspacesServiceBRSGates?.workspacesServiceBRSEnabled)return Promise.resolve(void 0);const c=["WorkspacesData"],u=r.I.getInstance();return u.fetchQuery(c,(()=>(0,p.m)(t,e,n,(e=>u.setQueryData(c,e)))),{staleTime:1/0,cacheTime:1/0})}},924671:(e,t,n)=>{n.d(t,{W:()=>r});var a=n(142826),o=n(589209);const r={key:"AppGalleryConfig",isGetClientGeneratedConfigEnabled:e=>!!e.resolveConfigGates?.resolveConfigAppGalleryEnabled,getClientGeneratedConfig:function(e){let{featureGates:t,featureSettings:n}=e;const a=n.appGallery,r=t.ecsAppGalleryUpdatesGates?.ecsAppGalleryUpdatesEnabled??!1,i=(0,o.X)(a?.numberOfBusinessApps??"0"),s=a?.myApplicationsUrl??"",p={};for(const e in a)e.startsWith("learnMoreLink")&&(p[e.charAt(0).toUpperCase()+e.slice(1)]=a[e]);return{numberOfBusinessApps:i,learnMoreLinks:p,myApplicationsUrl:s,ecsAppGalleryUpdatesEnabled:r}},getServerGeneratedConfig:e=>async function(e){return await(0,a.p)("appGalleryConfig",e)}(e)}},698654:(e,t,n)=>{n.d(t,{e:()=>r});var a=n(225268),o=n(924671);async function r(){return(0,a.D)(o.W)}},742862:(e,t,n)=>{async function a(e){const t=e.encryptionConfig?.cryptoKey;if(!t)return{key:null};const n=await async function(e){return window.crypto.subtle.importKey("jwk",e,"AES-GCM",!1,["encrypt","decrypt"])}(t);return{key:n}}n.d(t,{e:()=>a})},588494:(e,t,n)=>{n.d(t,{Z:()=>i});var a=n(673217),o=n(742862),r=n(854766);async function i(){const e=await(0,r.dw)(),t=["EncryptionKey",e.puid];return a.I.getInstance().fetchQuery(t,(()=>(0,o.e)(e)),{staleTime:1/0,cacheTime:1/0})}},944736:(e,t,n)=>{n.d(t,{bP:()=>o,zt:()=>r});const a=12;async function o(){const e="undefined"!=typeof window&&window.crypto||"undefined"!=typeof self&&self.crypto||globalThis.crypto;if(!e)throw new Error("Crypto API not available");return e.getRandomValues(new Uint8Array(a))}function r(e){return[e.slice(0,a),e.slice(a,e.byteLength)]}},236914:(e,t,n)=>{n.d(t,{Y:()=>o});var a=n(944736);async function o(e,t){const[n,o]=(0,a.zt)(e);return await window.crypto.subtle.decrypt({name:"AES-GCM",iv:n,tagLength:128},t,o)}},359726:(e,t,n)=>{n.d(t,{w:()=>r});var a=n(944736),o=n(7132);async function r(e,t){const n=await(0,a.bP)(),r="undefined"!=typeof window&&window.crypto||"undefined"!=typeof self&&self.crypto||globalThis.crypto;if(!r)throw new Error("Crypto API not available");const i=await r.subtle.encrypt({name:"AES-GCM",iv:n,tagLength:128},t,e);return(0,o.E)(n.buffer,i)}},7132:(e,t,n)=>{function a(e,t){const n=new Uint8Array(e.byteLength+t.byteLength);return n.set(new Uint8Array(e),0),n.set(new Uint8Array(t),e.byteLength),n.buffer}n.d(t,{E:()=>a})},12801:(e,t,n)=>{n.d(t,{J:()=>r});var a=n(359726),o=n(236914);function r(e){return{onBeforeWriteValue:async t=>{if(!t)return t;let n,o;return t instanceof ArrayBuffer?(n=t,o="rawbytes"):(n=(new TextEncoder).encode(JSON.stringify(t)).buffer,o="utf8-encoded-string"),{buffer:await(0,a.w)(n,e),payloadType:o}},onAfterReadValue:async t=>{if(!t)return t;const n=await(0,o.Y)(new Uint8Array(t.buffer),e);if("rawbytes"===t.payloadType)return n;{const e=(new TextDecoder).decode(new Uint8Array(n));return JSON.parse(e)}}}}},623257:(e,t,n)=>{n.d(t,{PZ:()=>s,VP:()=>c,ch:()=>l,re:()=>p,tl:()=>u});var a=n(552092),o=n(751924),r=n(766818),i=n(978163);const s=o.U`
  query AppBarControlQuery {
    views {
      appBarControl {
        id
        rootNavigationAriaLabel
        animateSelection
        enableMicaV2DesktopStyles
        enableMicaV2WebStyles
        enableMercuryDesignStyles
        enableOptimisticMutations
        appTilePositionEnabled
        impressionStabilizeTimeout
        enableAIHub
        enableBrandLogo
        enableVisualRefreshStyles
        enableRockSteadyForM365
        tileBehavior {
          transparent
          shouldRemoveLockedAppsFromPinnedApps
          shouldShowLabel
          dragDropEnabled
          overrideAppBarDefaultSort
          useOutlineIcon
          tileContextMenu {
            ...TileContextMenu_tileContextMenu
          }
          ...LaunchTile_launchTileBehavior
        }
        flyoutBehavior {
          flyoutSize
          selectFlyoutButtonWhenNoAppsSelected
          isSuggestionsSectionEnabled
          isQuickAccessSectionEnabled
          isSeeAllButtonEnabled
          seeAllButtonIndex
          enabledFlyoutButtonBadgeType
          searchBehavior {
            isEnabled
            placeholderText
            debounceRate
            noResultsTitle
            noResultsMessage
            resultsSectionTitle
            quickAccessResultsSectionTitle
          }
        }
        appAcquisitionLinkBehavior {
          linkFormat
        }
        localizedStrings {
          flyoutButtonBadgeDescription
          flyoutButtonText
          flyoutButtonTitle
          flyoutEmptyStateMessage
          flyoutSuggestedAppsPrivacyLinkText
          flyoutSuggestedAppsTermsOfUseLinkText
          flyoutSuggestedAppsPermissionsLinkText
          flyoutSuggestedAppsAddButtonText
          flyoutSuggestedAppsSectionTitle
          flyoutInstalledAppsSectionAriaLabel
          flyoutSearchResultsAriaLiveAnnouncement
          flyoutSuggestedAppsSectionAriaLabel
          flyoutInstalledAppsSearchResultsAnnouncement
          flyoutSuggestedAppsSearchResultsAnnouncement
          flyoutInstalledAndSuggestedAppsSearchResultsAnnouncement
          flyoutQuickAccessSectionTitle
          flyoutQuickAccessSectionAriaLabel
          flyoutSeeAllButtonLabel
          onDragStartText
          onDragEndText
          onDragOverText
          onDragCancelText
          onDragAtTopText
          onDragAtBottomText
        }
        flyoutIcon {
          __typename
          ... on InternalIcon {
            name
          }
          ... on RemoteImage {
            src
            isFullBleed
          }
        }
        flyoutIconSelected {
          __typename
          ... on InternalIcon {
            name
          }
          ... on RemoteImage {
            src
            isFullBleed
          }
        }
      }
    }
  }
  ${a.l}
  ${i.I}
`,p=o.U`
  query AppBarQuery {
    m365Apps {
      id
      edges {
        node {
          __typename
          id
          name
          platformType
          isInUse
          brandingColor
          lockedIndex
          pinnedIndex
          anchoredIndex
          hideFromSearch
          badge {
            __typename
            ... on M365ApplicationNumericBadge {
              count
            }
            ...TileBadge_badge
          }
          ...LaunchTile_m365App
        }
      }
      appAcquisitionLinks {
        id
        text
        accessibleName
        icon {
          name
        }
      }
    }
  }
  ${a.n}
  ${r.J}
`,l=o.U`
  mutation AppBarPinAppMutation($applicationID: ID!) {
    pinM365Application(input: { applicationID: $applicationID }) {
      __typename
      updatedM365Applications {
        __typename
        id
        platformType
        pinnedIndex
      }
    }
  }
`,c=o.U`
  mutation AppBarUnpinAppMutation($applicationID: ID!) {
    unpinM365Application(input: { applicationID: $applicationID }) {
      __typename
      updatedM365Applications {
        __typename
        id
        platformType
        pinnedIndex
      }
    }
  }
`,u=o.U`
  mutation AppBarMovePinnedAppMutation(
    $applicationID: ID!
    $newPinnedIndex: Int!
  ) {
    movePinnedM365Application(
      input: { applicationID: $applicationID, newPinnedIndex: $newPinnedIndex }
    ) {
      updatedM365Applications {
        id
        platformType
        pinnedIndex
      }
    }
  }
`},552092:(e,t,n)=>{n.d(t,{l:()=>i,n:()=>s});var a=n(751924),o=n(766818),r=n(978163);const i=a.U`
  fragment LaunchTile_launchTileBehavior on LaunchTileBehavior {
    transparent
    pinningEnabled
    appTilePositionEnabled
    useHubColorForSelectedTileLabel
    useOutlineIcon
    platformAppCommands {
      aboutCommandEnabled
      uninstallCommandEnabled
    }
    tileContextMenu {
      ...TileContextMenu_tileContextMenu
    }
  }
  ${r.I}
`,s=a.U`
  fragment LaunchTile_m365App on M365Application {
    id
    platformType
    name
    accessibleName
    icon {
      __typename
      ... on InternalIcon {
        name
      }
      ... on RemoteImage {
        src
        isFullBleed
      }
      ... on RemoteSVGImage {
        src
        isFullBleed
      }
    }
    outlineIcon {
      __typename
      ... on InternalIcon {
        name
      }
      ... on RemoteImage {
        src
        isFullBleed
      }
      ... on RemoteSVGImage {
        src
        isFullBleed
      }
    }
    badge {
      __typename
      ... on M365ApplicationNumericBadge {
        count
      }
      ...TileBadge_badge
    }
    selectedStateIconOverride {
      __typename
      ... on InternalIcon {
        name
      }
      ... on RemoteImage {
        src
        isFullBleed
      }
      ... on RemoteSVGImage {
        src
        isFullBleed
      }
    }
    brandingColor
    isInUse
    canLaunchOut
    enablePlatformCommands
    isPinnable
    lockedIndex
    pinnedIndex
    secondaryActions {
      id
      text
      icon {
        __typename
        ... on InternalIcon {
          name
        }
      }
      eventType
      eventData
    }
    ... on M365PlatformApplication {
      canBeUnacquired
    }
    allowedExternalDropContent
  }
  ${o.J}
`},766818:(e,t,n)=>{n.d(t,{J:()=>a});const a=n(751924).U`
  fragment TileBadge_badge on M365ApplicationBadge {
    __typename
    ... on M365ApplicationNumericBadge {
      count
      countDescription
    }
    ... on M365ApplicationDotBadge {
      description
    }
    ... on M365ApplicationStringBadge {
      text
      textDescription
    }
  }
`},978163:(e,t,n)=>{n.d(t,{I:()=>a}),n(571124);const a=n(751924).U`
  fragment TileContextMenu_tileContextMenu on TileContextMenu {
    openInNewTabItemLabel
    aboutAppItemLabel
    unpinAppItemLabel
    pinAppItemLabel
    uninstallAppItemLabel
    moveAppUpItemLabel
    moveAppDownItemLabel
    pinAriaAnnouncement
    unpinAriaAnnouncement
  }
`},751924:(e,t,n)=>{n.d(t,{U:()=>o});var a=n(832478);function o(e){for(var t=arguments.length,n=new Array(t>1?t-1:0),o=1;o<t;o++)n[o-1]=arguments[o];return(0,a.U)(e,...n)}},832478:(e,t,n)=>{n.d(t,{U:()=>r});var a=n(556719),o=n(891087);function r(e,...t){o(1===e.map((e=>e.trim())).filter((e=>e.length>0)).length,"Interpolations are only allowed at the end of the template.");const n=(0,a.qg)(e[0],{noLocation:!0}),r=new Set(n.definitions);return t.forEach((e=>e.definitions.forEach((e=>r.add(e))))),{kind:"Document",definitions:Array.from(r)}}},92621:(e,t,n)=>{n.d(t,{Em:()=>r,I3:()=>i,Nj:()=>s,Rs:()=>l,WY:()=>p,n_:()=>c});var a=n(124493),o=n(891087);function r(e,t,n){const r=(0,a.l)();return o(r.useLazyLoadQuery,"Expected host to provide a useLazyLoadQuery hook"),r.useLazyLoadQuery(e,t,n)}function i(e,t){var n,o;return(null==(o=(n=(0,a.l)()).useFragment)?void 0:o.call(n,e,t))||t}function s(e,t){const n=(0,a.l)();return o(n.useRefetchableFragment,"Expected host to provide a useRefetchableFragment hook"),n.useRefetchableFragment(e,t)}function p(e,t){const n=(0,a.l)();return o(n.usePaginationFragment,"Expected host to provide a usePaginationFragment hook"),n.usePaginationFragment(e,t)}function l(e){const t=(0,a.l)();o(t.useSubscription,"Expected host to provide a useSubscription hook"),t.useSubscription(e)}function c(e){const t=(0,a.l)();return o(t.useMutation,"Expected host to provide a useMutation hook"),t.useMutation(e)}}}]);